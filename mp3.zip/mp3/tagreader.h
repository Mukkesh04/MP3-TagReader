#ifndef TAGREADER_H
#define TAGREADER_H


void help(void);
void view(FILE *fp);
void edit(FILE **fp ,char*filename);




#endif
