#include<stdio.h>
#include<string.h>
#include<stdlib.h>

void help(void)
{
	printf("Functionalities available :\n");
	printf("%s\n%s\n%s\n%s\n%s\n%s\n%s\n","1. -t Modifies Title tag","2. -T Modifies Track tag","3. -a  Modifies Artist tag","4. -A Modifies Album tag","5. -y Modifies Year tag","6. -c Modifies Comment tag","7. -g Modifies Genre tag");
}

void view(FILE *fp)
{
	unsigned char buffer[5];
	fseek(fp, 7, SEEK_CUR);
	char tag[5];
	
	for(int i = 0 ; i < 7 ; i++)
	{
	fread(tag,1,4,fp);
	tag[4]='\0';
	if (strcmp(tag,"TIT2")==0)
	{
		printf("Title : ");
	}
	else if(strcmp(tag,"TPE1")==0)
	{
		printf("Artist : ");
	}
	else if(strcmp(tag,"TALB")==0)
	{
		printf("Album : ");
	}
	else if(strcmp(tag,"TYER")==0)
	{
		printf("Year of the release : ");
	}
	else if(strcmp(tag,"TRCK")==0)
	{
		printf("Track number : ");
	}
	else if(strcmp(tag,"TCON")==0)
	{
		printf("Genre : ");
	}
	else if(strcmp(tag,"COMM")==0)
	{
		printf("Comment : ");
	}
	
	fread(buffer,1,4,fp);

	unsigned char temp;

	temp = buffer[0] ;
	buffer[0] = buffer[3];
	buffer[3] = temp;

	temp = buffer[1] ;
	buffer[1] = buffer[2];
	buffer[2] = temp;


	int frame_size;

	memcpy(&frame_size, buffer, 4);
	
	fseek(fp , 3 , SEEK_CUR);
//printf("DEBUG -> Tag: %s, Frame size: %d\n", tag, frame_size);
	char content[frame_size+1];
	fread(content,1,frame_size-1,fp);
	content[frame_size-1] = '\0';
	printf("%s\n", content);

	}
}
void edit(FILE** fp_ptr,char *filename)
{
	FILE *fp = *fp_ptr;
	rewind(fp);
	help();
	printf("Enter the choice : ");
	char choice[16];
	scanf(" %15[^\n]",choice);
 char target_tag[5];
    char new_content[256];
	 switch (choice[1])
    {
        case 't':
            strcpy(target_tag, "TIT2");
            break;

        case 'a':
            strcpy(target_tag, "TPE1");
            break;

        case 'A':
            strcpy(target_tag, "TALB");
            break;

        case 'y':
            strcpy(target_tag, "TYER");
            break;

        case 'T':
            strcpy(target_tag, "TRCK");
            break;

        case 'c':
            strcpy(target_tag, "COMM");
            break;

        case 'g':
            strcpy(target_tag, "TCON");
            break;

        default:
            printf("Invalid choice\n");
            return;
    }
 printf("Enter the new content: ");
    scanf(" %255[^\n]", new_content);

    /* Temporary file */
    FILE *temp_fp = fopen("temp.mp3", "wb");

    if (temp_fp == NULL)
    {
        printf("Unable to create temporary file\n");
        return;
    }

     rewind(fp);
    unsigned char header[10];

    fread(header, 1, 10, fp);
    fwrite(header, 1, 10, temp_fp);
    int tag_size;

tag_size = ((header[6] & 0x7F) << 21) |
           ((header[7] & 0x7F) << 14) |
           ((header[8] & 0x7F) << 7)  |
           (header[9] & 0x7F);
long tag_end = 10 + tag_size;
    char tag[5];
    unsigned char size_buffer[4];
    int modified = 0;
    long frames_bytes_written = 0; /* bytes written after the 10-byte header, for fixing up tag_size */
   while(ftell(fp) < tag_end)
    {
	   if( fread(tag,1,4,fp)!= 4)
		   break;
	   tag[4] = '\0';
if (tag[0] == '\0')
{
    fseek(fp, -4, SEEK_CUR); /* push the padding bytes back so they aren't lost, and get copied verbatim below */
    break;
}
	   if(fread(size_buffer,1,4,fp)!= 4)
		   break;

	   unsigned char temp;

	   temp = size_buffer[0];
	   size_buffer[0] = size_buffer[3];
	   size_buffer[3] = temp;

	   temp = size_buffer[1];
           size_buffer[1] = size_buffer[2];
           size_buffer[2] = temp;

	int frame_size;
	memcpy(&frame_size ,size_buffer,4);
	

	temp = size_buffer[0];
           size_buffer[0] = size_buffer[3];
           size_buffer[3] = temp;

           temp = size_buffer[1];
           size_buffer[1] = size_buffer[2];
           size_buffer[2] = temp;

	unsigned char flag[2];
	   fread(flag, 1,2,fp);

	   fwrite(tag,1,4,temp_fp);

	   if(strcmp(tag,target_tag)==0)
	   {
		  int new_size = strlen(new_content) + 1;
	   

	    unsigned char newsizebuffer[4];
	    newsizebuffer[0] = (new_size >> 24) & 0xFF; 
	    newsizebuffer[1] = (new_size >> 16) & 0xFF; 
	    newsizebuffer[2] = (new_size >> 8) & 0xFF; 
	    newsizebuffer[3] = (new_size & 0xFF);

	   fwrite(newsizebuffer,1,4,temp_fp);
	   fwrite(flag,1,2,temp_fp);
	   
	   unsigned char  encoding = 0 ;

	   fwrite(&encoding , 1,1,temp_fp);

	   fwrite(new_content,1,strlen(new_content),temp_fp);

	   modified = 1;

	   frames_bytes_written += 4 + 4 + 2 + new_size; /* tag + size + flags + content */

	   fseek(fp,frame_size,SEEK_CUR);
	   
	   }

	   else
	   {
	   	fwrite(size_buffer,1,4,temp_fp);

		fwrite(flag,1,2,temp_fp);

		char *content = malloc(frame_size > 0 ? frame_size : 1);
		if (content == NULL)
		{
			printf("Out of memory while copying frame\n");
			fclose(temp_fp);
			fclose(fp);
			*fp_ptr = NULL;
			return;
		}

		fread(content,1,frame_size,fp);

		fwrite(content ,1,frame_size,temp_fp);

		free(content);

		frames_bytes_written += 4 + 4 + 2 + frame_size; /* tag + size + flags + content */

	   }
    }
	    char copy_buffer[1024];
	    size_t bytes;
	    while((bytes = fread(copy_buffer,1,1024,fp)) > 0)
	    {
		    fwrite(copy_buffer,1,bytes,temp_fp);
	    }
	    fclose(fp);

	    if (modified)
	    {
		/* Patch the ID3 header's synch-safe tag size so it reflects the
		   possibly-changed total size of the tag frames (a resized frame
		   shifts the total tag length). Without this, real ID3 readers
		   (and any future re-run of this tool relying on the header)
		   would mis-parse the tag. */
		unsigned char size_field[4];
		size_field[0] = (frames_bytes_written >> 21) & 0x7F;
		size_field[1] = (frames_bytes_written >> 14) & 0x7F;
		size_field[2] = (frames_bytes_written >> 7)  & 0x7F;
		size_field[3] = frames_bytes_written & 0x7F;
		fseek(temp_fp, 6, SEEK_SET);
		fwrite(size_field, 1, 4, temp_fp);
	    }

	    fclose(temp_fp);

	    if (modified)
	    {
		remove(filename);
		rename("temp.mp3",filename);
		printf("Modification done successfully\n");
	    }
	    else
	    {
		remove("temp.mp3"); /* discard the unused temp file */
		printf("Requested tag not found\n");
	    }

	    /* fp was closed above (and, if modified, the file on disk was
	       replaced). The caller's FILE* is now stale either way, so we
	       must reopen the file at `filename` and hand back a fresh,
	       valid stream via fp_ptr - otherwise every menu option after
	       Edit reads through a dangling FILE*, which is what caused the
	       garbage output. */
	    FILE *new_fp = fopen(filename, "rb");
	    if (new_fp == NULL)
	    {
		printf("Warning: could not reopen %s after editing\n", filename);
		*fp_ptr = NULL;
		return;
	    }
	    fseek(new_fp, 3, SEEK_SET); /* skip past the "ID3" identifier, matching main()'s initial read */
	    *fp_ptr = new_fp;
}
