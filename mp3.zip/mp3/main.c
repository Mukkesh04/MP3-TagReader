#include<stdio.h>
#include"tagreader.h"
#include<string.h>
int main(int argc , char **argv)
{
	if (argc < 2)
	{
		printf("insufficient arguments ,Please enter file name\n");
		return 0;
	}

	int option;
	FILE *fp;

	fp = fopen(argv[1],"rb");

	if(fp == NULL)
	{
		printf("File does not exist\n");
		return 0;
	}
	char buffer[4];
	fread(buffer,1,3,fp);
	buffer[3] = '\0';
	if(strcmp(buffer ,"ID3") != 0)
	{
		printf("Error: Invalid file format\n");
		fclose(fp);
		return 0;
	}

while(1)
{
	printf("======================== MP3 Reader Menu=======================\n\n");
	printf("1. Help\n2. View Metadata\n3. Edit Metadata\n4. Exit Application\n");
	printf("======================== Enter any option =====================\n\n");
	scanf("%d",&option);

	switch(option)
	{
	case 1:
		help();
		break;
	case 2:
		view(fp);
		break;
	case 3: 
		edit(&fp,argv[1]);
		if (fp == NULL)
		{
			printf("Edit failed and file could not be reopened, exiting.\n");
			return 0;
		}
		break;
	case 4:
		{
			printf("Exiting.....\n");
			return 0;
		}
	}
}

}
